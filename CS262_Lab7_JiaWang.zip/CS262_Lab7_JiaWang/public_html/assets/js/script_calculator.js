// *******************************DOM conversion of HTML codes****************************************
let docBody = document.querySelector("body");
let docDivWrapper = document.createElement("div");
docDivWrapper.setAttribute("class", "wrapper_calculator");

let docIdCalculator = document.createElement("div");
docIdCalculator.setAttribute("id", "calculator");

let docIdCalculation = document.createElement("div");
docIdCalculation.setAttribute("id", "calculation");

let docIdOutput = document.createElement("div");
docIdOutput.setAttribute("id", "output");

let docIdClear = document.createElement("div");
docIdClear.setAttribute("id", "clear");
docIdClear.appendChild(document.createTextNode("C"));

let docIdDelete = document.createElement("div");
docIdDelete.setAttribute("id", "delete");
let docIdArrow = document.createElement("div");
docIdArrow.setAttribute("class", "arrow");
docIdDelete.appendChild(docIdArrow);

let docIdDivide = document.createElement("div");
docIdDivide.setAttribute("id", "divide");
docIdDivide.appendChild(document.createTextNode("/"));

let docIdMultiply = document.createElement("div");
docIdMultiply.setAttribute("id", "multiply");
docIdMultiply.appendChild(document.createTextNode("*"));

let docIdSubtract = document.createElement("div");
docIdSubtract.setAttribute("id", "subtract");
docIdSubtract.appendChild(document.createTextNode("-"));

let docIdAdd = document.createElement("div");
docIdAdd.setAttribute("id", "add");
docIdAdd.appendChild(document.createTextNode("+"));

let docIdEqual = document.createElement("div");
docIdEqual.setAttribute("id", "equal");
docIdEqual.appendChild(document.createTextNode("="));

let docIdPoint = document.createElement("div");
docIdPoint.setAttribute("id", "point");
docIdPoint.appendChild(document.createTextNode("."));

let docIdZero = document.createElement("div");
docIdZero.setAttribute("id", "zero");
docIdZero.appendChild(document.createTextNode("0"));

let docIdOne = document.createElement("div");
docIdOne.setAttribute("id", "one");
docIdOne.appendChild(document.createTextNode("1"));

let docIdTwo = document.createElement("div");
docIdTwo.setAttribute("id", "two");
docIdTwo.appendChild(document.createTextNode("2"));

let docIdThree = document.createElement("div");
docIdThree.setAttribute("id", "three");
docIdThree.appendChild(document.createTextNode("3"));

let docIdFour = document.createElement("div");
docIdFour.setAttribute("id", "four");
docIdFour.appendChild(document.createTextNode("4"));

let docIdFive = document.createElement("div");
docIdFive.setAttribute("id", "five");
docIdFive.appendChild(document.createTextNode("5"));

let docIdSix = document.createElement("div");
docIdSix.setAttribute("id", "six");
docIdSix.appendChild(document.createTextNode("6"));

let docIdSeven = document.createElement("div");
docIdSeven.setAttribute("id", "seven");
docIdSeven.appendChild(document.createTextNode("7"));

let docIdEight = document.createElement("div");
docIdEight.setAttribute("id", "eight");
docIdEight.appendChild(document.createTextNode("8"));

let docIdNine = document.createElement("div");
docIdNine.setAttribute("id", "nine");
docIdNine.appendChild(document.createTextNode("9"));

docIdCalculator.appendChild(docIdCalculation);
docIdCalculator.appendChild(docIdOutput);
docIdCalculator.appendChild(docIdClear);
docIdCalculator.appendChild(docIdDelete);
docIdCalculator.appendChild(docIdDivide);
docIdCalculator.appendChild(docIdMultiply);
docIdCalculator.appendChild(docIdSubtract);
docIdCalculator.appendChild(docIdAdd);
docIdCalculator.appendChild(docIdEqual);
docIdCalculator.appendChild(docIdPoint);
docIdCalculator.appendChild(docIdZero);
docIdCalculator.appendChild(docIdOne);
docIdCalculator.appendChild(docIdTwo);
docIdCalculator.appendChild(docIdThree);
docIdCalculator.appendChild(docIdFour);
docIdCalculator.appendChild(docIdFive);
docIdCalculator.appendChild(docIdSix);
docIdCalculator.appendChild(docIdSeven);
docIdCalculator.appendChild(docIdEight);
docIdCalculator.appendChild(docIdNine);

docDivWrapper.appendChild(docIdCalculator);

docBody.appendChild(docDivWrapper);

// *******************************End of DOM conversion of HTML codes****************************************

// *******************************DOM conversion of CSS codes****************************************
var htmlStyle = document.querySelector("html");
htmlStyle.style.height = "100%";
htmlStyle.style.margin = "0";
htmlStyle.style.fontFamily = "\"Courier New\", Courier, monospace";
htmlStyle.style.color = "#fff";

var bodyStyle = document.querySelector("body");
bodyStyle.style.height = "100%";
bodyStyle.style.margin = "0";

var wrapperStyle = document.querySelector(".wrapper_calculator");
wrapperStyle.style.alignItems = "center";
wrapperStyle.style.background = "rgb(125, 131, 179)";
wrapperStyle.style.backgroundImage = "linear-gradient(45deg, rgba(0, 0, 0, 0.5), transparent)";
wrapperStyle.style.display = "flex";
wrapperStyle.style.justifyContent = "center";
wrapperStyle.style.height = "100%";
wrapperStyle.style.minHeight = "600px";
wrapperStyle.style.padding = "50px";

var calculatorStyle = document.querySelector("#calculator");
calculatorStyle.style.borderRadius = "10px";
calculatorStyle.style.boxShadow = "inset 5px 5px 10px 0px rgba(255, 255, 255, 1), inset -5px -5px 10px 0px rgba(0, 0, 0, 0.5)";
calculatorStyle.style.display = "grid";
calculatorStyle.style.fontSize = "3em";
calculatorStyle.style.gridGap = "0.25em";
calculatorStyle.style.gridTemplateAreas = '"calculation calculation calculation calculation" "output       output      output         output" "clearBtn   divideBtn   multiplyBtn   subtractBtn" "sevenBtn    eightBtn    nineBtn        addBtn" "fourBtn    fiveBtn      sixBtn         addBtn" "oneBtn       twoBtn     threeBtn      equalBtn" "delete     zeroBtn       pointBtn      equalBtn"';
calculatorStyle.style.gridTemplateColumns = "repeat(4, 1fr)";
calculatorStyle.style.height = "100%";
calculatorStyle.style.maxHeight = "600px";
calculatorStyle.style.maxWidth = "1200px";
calculatorStyle.style.minHeight = "500px";
calculatorStyle.style.padding = "20px";
calculatorStyle.style.width = "100%";

var i;
// var calculatorDivStyle = document.querySelector("#calculator").querySelectorAll("div");
var calculatorDivStyle = document.querySelectorAll("#calculator div");
for (i = 0; i < calculatorDivStyle.length; i++) {
    calculatorDivStyle[i].style.alignItems = "center";
    calculatorDivStyle[i].style.background = "rgba(255, 255, 255, 0.1)";
    calculatorDivStyle[i].style.borderRadius = "4px";
    calculatorDivStyle[i].style.boxShadow = "inset 2px 2px 4px 0px rgba(255, 255, 255, 1), inset -2px -2px 4px 0px rgba(0, 0, 0, 0.5), 2px 2px 4px 0px rgba(0, 0, 0, 0.25)";
    calculatorDivStyle[i].style.cursor = "pointer";
    calculatorDivStyle[i].style.display = "flex";
    calculatorDivStyle[i].style.justifyContent = "center";

    // Emulation of hover and click events
    calculatorDivStyle[i].onmouseover = function() {
        this.style.background = "rgba(255, 255, 255, 0.2)";
    }
    calculatorDivStyle[i].onmouseout = function() {
        this.style.background = "rgba(255, 255, 255, 0.1)";
    }
    calculatorDivStyle[i].onmousedown = function() {
        this.style.background = "rgba(0, 0, 0, 0.05)";
        this.style.boxShadow = "inset 2px 2px 4px 0px rgba(0, 0, 0, 0.5), inset -2px -2px 4px 0px rgba(255, 255, 255, 1)";
    }
    calculatorDivStyle[i].onmouseup = function() {
        this.style.background = "rgba(255, 255, 255, 0.1)";
        this.style.boxShadow = "inset 2px 2px 4px 0px rgba(255, 255, 255, 1), inset -2px -2px 4px 0px rgba(0, 0, 0, 0.5), 2px 2px 4px 0px rgba(0, 0, 0, 0.25)";
    }
}

let calculationDivStyle = document.querySelector("#calculator #calculation");
calculationDivStyle.style.background = "transparent";
calculationDivStyle.style.boxShadow = "inset 2px 2px 4px 0px rgba(0, 0, 0, 0.15), inset -2px -2px 4px 0px rgba(255, 255, 255, 0.25)";
calculationDivStyle.style.borderWidth = "0px";
calculationDivStyle.style.color = "#ddd";
calculationDivStyle.style.cursor = "default";
calculationDivStyle.style.fontSize = "0.5em";
calculationDivStyle.style.gridArea = "calculation";
calculationDivStyle.style.height = "1.5em";
calculationDivStyle.style.justifyContent = "flex-end";
calculationDivStyle.style.overflow = "hidden";
calculationDivStyle.style.padding = "0.5em";

let outputDivStyle = document.querySelector("#calculator #output");
outputDivStyle.style.background = "rgba(0, 0, 0, 0.05)";
outputDivStyle.style.boxShadow = "inset 2px 2px 4px 0px rgba(255, 255, 255, 1), inset -2px -2px 4px 0px rgba(0, 0, 0, 0.5)";
outputDivStyle.style.cursor = "default";
outputDivStyle.style.gridArea = "output";
outputDivStyle.style.height = "1.5em";
outputDivStyle.style.justifyContent = "flex-end";
outputDivStyle.style.padding = "0.5em";

// let calculationSelectionPseudoElementBackground = window.getComputedStyle(document.querySelector('#calculator #calculation'), '::selection').getPropertyValue('background');
// let calculationSelectionPseudoElementColor = window.getComputedStyle(document.querySelector('#calculator #calculation'), '::selection').getPropertyValue('color');
// calculationSelectionPseudoElement.toEqual('rgba(0, 0, 0, 0.5)');
// calculationSelectionPseudoElementColor.toEqual('#fff');

let clearGridStyle = document.querySelector("#clear");
clearGridStyle.style.gridArea = "clearBtn";

let addGridStyle = document.querySelector("#add");
addGridStyle.style.gridArea = "addBtn";

let subtractGridStyle = document.querySelector("#subtract");
subtractGridStyle.style.gridArea = "subtractBtn";

let multiplyGridStyle = document.querySelector("#multiply");
multiplyGridStyle.style.gridArea = "multiplyBtn";

let divideGridStyle = document.querySelector("#divide");
divideGridStyle.style.gridArea = "divideBtn";

let equalGridStyle = document.querySelector("#equal");
equalGridStyle.style.gridArea = "equalBtn";

let deleteGridStyle = document.querySelector("#delete");
deleteGridStyle.style.gridArea = "delete";

let arrowGraphicStyle = document.querySelector("#delete .arrow");
arrowGraphicStyle.style.backgroundColor = "#fff";
arrowGraphicStyle.style.borderRadius = "1px 0 0 1px";
arrowGraphicStyle.style.height = "2px";
arrowGraphicStyle.style.position = "relative";
arrowGraphicStyle.style.width = "40px";

let pointGridStyle = document.querySelector("#point");
pointGridStyle.style.gridArea = "pointBtn";

let zeroGridStyle = document.querySelector("#zero");
zeroGridStyle.style.gridArea = "zeroBtn";
let oneGridStyle = document.querySelector("#one");
oneGridStyle.style.gridArea = "oneBtn";
let twoGridStyle = document.querySelector("#two");
twoGridStyle.style.gridArea = "twoBtn";
let threeGridStyle = document.querySelector("#three");
threeGridStyle.style.gridArea = "threeBtn";
let fourGridStyle = document.querySelector("#four");
fourGridStyle.style.gridArea = "fourBtn";
let fiveGridStyle = document.querySelector("#five");
fiveGridStyle.style.gridArea = "fiveBtn";
let sixGridStyle = document.querySelector("#six");
sixGridStyle.style.gridArea = "sixBtn";
let sevenGridStyle = document.querySelector("#seven");
sevenGridStyle.style.gridArea = "sevenBtn";
let eightGridStyle = document.querySelector("#eight");
eightGridStyle.style.gridArea = "eightBtn";
let nineGridStyle = document.querySelector("#nine");
nineGridStyle.style.gridArea = "nineBtn";




// *******************************End of DOM conversion of CSS codes****************************************

// *******************************Calculator functionalities****************************************
// Some (not all) Number Buttons

let calculationStringAccumulator = "";
let calculationStringAccumulatorArray = [];
let calculationResultArray = [];
let accumulator = 0;

const zeroBtn = document.querySelector("#zero");
const zero = parseInt(zeroBtn.innerText);

zeroBtn.addEventListener("click", function() {
    if (calculationStringAccumulator.length > 0) {
        calculationStringAccumulator += zero;
        calculation.innerText = `${calculationStringAccumulator}`;
        output.innerText = `${calculationStringAccumulator}`;
    }
});

const oneBtn = document.querySelector("#one");
const one = parseInt(oneBtn.innerText);

oneBtn.addEventListener("click", function() {
    calculationStringAccumulator += one;
    calculation.innerText = `${calculationStringAccumulator}`;
    output.innerText = `${calculationStringAccumulator}`;
});

const twoBtn = document.querySelector("#two");
const two = parseInt(twoBtn.innerText);

twoBtn.addEventListener("click", function() {
    calculationStringAccumulator += two;
    calculation.innerText = `${calculationStringAccumulator}`;
    output.innerText = `${calculationStringAccumulator}`;
});

const threeBtn = document.querySelector("#three");
const three = parseInt(threeBtn.innerText);

threeBtn.addEventListener("click", function() {
    calculationStringAccumulator += three;
    calculation.innerText = `${calculationStringAccumulator}`;
    output.innerText = `${calculationStringAccumulator}`;
});

const fourBtn = document.querySelector("#four");
const four = parseInt(fourBtn.innerText);

fourBtn.addEventListener("click", function() {
    calculationStringAccumulator += four;
    calculation.innerText = `${calculationStringAccumulator}`;
    output.innerText = `${calculationStringAccumulator}`;
});

const fiveBtn = document.querySelector("#five");
const five = parseInt(fiveBtn.innerText);

fiveBtn.addEventListener("click", function() {
    calculationStringAccumulator += five;
    calculation.innerText = `${calculationStringAccumulator}`;
    output.innerText = `${calculationStringAccumulator}`;
});

const sixBtn = document.querySelector("#six");
const six = parseInt(sixBtn.innerText);

sixBtn.addEventListener("click", function() {
    calculationStringAccumulator += six;
    calculation.innerText = `${calculationStringAccumulator}`;
    output.innerText = `${calculationStringAccumulator}`;
});

const sevenBtn = document.querySelector("#seven");
const seven = parseInt(sevenBtn.innerText);

sevenBtn.addEventListener("click", function() {
    calculationStringAccumulator += seven;
    calculation.innerText = `${calculationStringAccumulator}`;
    output.innerText = `${calculationStringAccumulator}`;
});

const eightBtn = document.querySelector("#eight");
const eight = parseInt(eightBtn.innerText);

eightBtn.addEventListener("click", function() {
    calculationStringAccumulator += eight;
    calculation.innerText = `${calculationStringAccumulator}`;
    output.innerText = `${calculationStringAccumulator}`;
});

const nineBtn = document.querySelector("#nine");
const nine = parseInt(nineBtn.innerText);

nineBtn.addEventListener("click", function() {
    calculationStringAccumulator += nine;
    calculation.innerText = `${calculationStringAccumulator}`;
    output.innerText = `${calculationStringAccumulator}`;
});


let pointBoolean = true;
const pointBtn = document.querySelector("#point");
const point = pointBtn.innerText;

pointBtn.addEventListener("click", function(event) {
    if (pointBoolean) {
        calculationStringAccumulator += event.target.innerText;
        calculation.innerText = `${calculationStringAccumulator}`;
    }
    pointBoolean = false;
});

const bkspBtn = document.querySelector("#delete");

bkspBtn.addEventListener("click", function(event) {
    if (calculationStringAccumulator.length > 0) {
        // calculationStringAccumulator.pop;
        calculationStringAccumulator = calculationStringAccumulator.substring(0, calculationStringAccumulator.length - 1);
        calculation.innerText = `${calculationStringAccumulator}`;
        output.innerText = `${calculationStringAccumulator}`;
    }
    // calculationStringAccumulator = calculationStringAccumulator.substring(0, calculationStringAccumulator.length - 1);
});
const addBtn = document.querySelector("#add");
const addsign = addBtn.innerText;
var i;

addBtn.addEventListener("click", function(event) {
    calculationStringAccumulatorArray.push(Number(calculationStringAccumulator));
    calculationStringAccumulatorArray.push(addsign);
    calculation.innerText = "";
    for (i = 0; i < calculationStringAccumulatorArray.length; i++) {
        calculation.innerText += `${calculationStringAccumulatorArray[i]}`;
    }
    calculationStringAccumulator = "";
    pointBoolean = true;

});

const multiplyBtn = document.querySelector("#multiply");
const multiplysign = multiplyBtn.innerText;
multiplyBtn.addEventListener("click", function(event) {
    calculationStringAccumulatorArray.push(Number(calculationStringAccumulator));
    calculationStringAccumulatorArray.push(multiplysign);
    calculation.innerText = "";
    for (i = 0; i < calculationStringAccumulatorArray.length; i++) {
        calculation.innerText += `${calculationStringAccumulatorArray[i]}`;
    }
    calculationStringAccumulator = "";
    pointBoolean = true;

});

const divideBtn = document.querySelector("#divide");
const dividesign = divideBtn.innerText;
divideBtn.addEventListener("click", function(event) {
    calculationStringAccumulatorArray.push(Number(calculationStringAccumulator));
    calculationStringAccumulatorArray.push(dividesign);
    calculation.innerText = "";
    for (i = 0; i < calculationStringAccumulatorArray.length; i++) {
        calculation.innerText += `${calculationStringAccumulatorArray[i]}`;
    }
    calculationStringAccumulator = "";
    pointBoolean = true;

});

const subtractBtn = document.querySelector("#subtract");
const subtractsign = subtractBtn.innerText;
subtractBtn.addEventListener("click", function(event) {
    calculationStringAccumulatorArray.push(Number(calculationStringAccumulator));
    calculationStringAccumulatorArray.push(subtractsign);
    calculation.innerText = "";
    for (i = 0; i < calculationStringAccumulatorArray.length; i++) {
        calculation.innerText += `${calculationStringAccumulatorArray[i]}`;
    }
    calculationStringAccumulator = "";
    pointBoolean = true;

});


// Some (not all) Function Buttons
const equalBtn = document.querySelector("#equal");
const clear = document.getElementById("clear");

// Output Elements
const calculation = document.getElementById("calculation");
const output = document.getElementById("output");

// HTMLelement.addEventListener("string", "function");
equalBtn.addEventListener("click", function() {

    calculation.innerText = "";
    if (calculationStringAccumulator != "") {
        calculationStringAccumulatorArray.push(Number(calculationStringAccumulator));
    }

    // calculationResultArray = [...calculationStringAccumulatorArray];

    // if (calculationResultArray[calculationResultArray.length - 1] !== "+" || calculationResultArray[calculationResultArray.length - 1] !== "-" || calculationResultArray[calculationResultArray.length - 1] !== "*" || calculationResultArray[calculationResultArray.length - 1] !== "/") {
    //     calculationStringAccumulatorArray.push(Number(calculationStringAccumulator));
    //     calculationResultArray.push(Number(calculationStringAccumulator));
    // }

    if (calculationStringAccumulatorArray[calculationStringAccumulatorArray.length - 1] === "+" || calculationStringAccumulatorArray[calculationStringAccumulatorArray.length - 1] === "-" || calculationStringAccumulatorArray[calculationStringAccumulatorArray.length - 1] === "*" || calculationStringAccumulatorArray[calculationStringAccumulatorArray.length - 1] === "/") {
        console.log("sign", calculationStringAccumulatorArray[calculationStringAccumulatorArray.length - 1]);
        calculationStringAccumulatorArray.pop();
        console.log("no push", calculationStringAccumulatorArray);
    }



    calculationResultArray = calculationStringAccumulatorArray.slice();
    // console.log("after test", calculationResultArray);

    // for (i = 0; i < calculationResultArray.length; i++) {
    //     if (calculationResultArray[i] == "*") {
    //         accumulator = Number(calculationResultArray[i - 1]) * Number(calculationResultArray[i + 1]);
    //     }
    //     if (calculationResultArray[i] == "/") {
    //         if (calculationResultArray[i + 1] !== 0) {
    //             accumulator = Number(calculationResultArray[i - 1]) / Number(calculationResultArray[i + 1]);
    //         } else {
    //             window.alert("Second operand in division cannot be zero!");
    //         }
    //     }
    // }


    // let anotherTemp = [1, "+", 2, "+", 3, "+", 4]
    // anotherTemp.splice(1 - 1, 2);
    // anotherTemp.splice(1 - 1, 1, 3);
    // https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures/basic-javascript/replace-loops-using-recursion

    // console.log(anotherTemp);
    // for (i = 0; i < calculationResultArray.length; i++) {
    //     if (calculationResultArray[i] == "+") {
    //         accumulator = Number(calculationResultArray[i - 1]) + Number(calculationResultArray[i + 1]);
    //         calculationResultArray.splice(i - 1, 2);
    //         console.log(calculationResultArray);
    //         calculationResultArray.splice(i - 1, 1, accumulator);
    //         console.log(calculationResultArray);
    //     }
    // }

    // let hintArrayReminderForLastMember = ["333", "+", "411", "+", "521", "+", "456", "+ || - || * || /"];

    // let hintArrayRE_PEMDAS = [1, "+", 2, "*", 3];
    // let tempHintArrayRE_PEMDAS = [1, "+", 6];
    // hintArrayRE_PEMDAS.forEach((ele, index) => {
    //     if (ele === "*" || ele === "/") {
    //         // first do that
    //         console.log(ele, index);
    //     }
    // });
    // accumulator = 0;
    processResultArray(calculationResultArray);

    for (i = 0; i < calculationStringAccumulatorArray.length; i++) {
        calculation.innerText += `${calculationStringAccumulatorArray[i]}`;
    }
    // console.log(calculationStringAccumulatorArray);
    // console.log(calculationResultArray);

    output.innerText = accumulator;
});


// || calculationStringAccumulatorArray[i] == "-" || calculationStringAccumulatorArray[i] == "*" || calculationStringAccumulatorArray[i] == "/"
function add(numOne, numTwo) {
    calculation.innerText = `${numOne} + ${numTwo}`;
    output.innerText = numOne + numTwo;
    // You will want to add numTwo to some kind of accumulator.
}

// The event listener below seems complete. IT IS NOT. More will need to happen on clear.
clear.addEventListener("click", function() {
    calculation.innerText = "";
    output.innerText = "";
    pointBoolean = true;
    console.clear();
    calculationStringAccumulatorArray = [];
    calculationStringAccumulator = "";
});

// Subtle hint below. You will need to work with an accumulator. You 'may' want to use an object for the current arithmetic operator, current total and current number selected, but it is not needed.
function AddFunction(calculationStringAccumulator, numTwo) {
    calculationStringAccumulator = calculationStringAccumulator + numTwo;
}

function processResultArray(calculationResultArray) {
    if (calculationResultArray.length > 1) {

        for (i = 0; i < calculationResultArray.length; i++) {
            if (calculationResultArray[i] == "*") {
                accumulator = Number(calculationResultArray[i - 1]) * Number(calculationResultArray[i + 1]);
                console.log("before splice", calculationResultArray);
                calculationResultArray.splice(i - 1, 2);
                calculationResultArray.splice(i - 1, 1, accumulator);
                console.log("after splice", calculationResultArray);
                processResultArray(calculationResultArray);
            }
            if (calculationResultArray[i] == "/") {
                if (calculationResultArray[i + 1] !== 0) {
                    accumulator = Number(calculationResultArray[i - 1]) / Number(calculationResultArray[i + 1]);
                    calculationResultArray.splice(i - 1, 2);
                    calculationResultArray.splice(i - 1, 1, accumulator);
                    processResultArray(calculationResultArray);
                } else {
                    window.alert("Second operand in division cannot be zero!");
                }
            }
        }

        for (i = 0; i < calculationResultArray.length; i++) {
            if (calculationResultArray[i] == "+") {
                accumulator = Number(calculationResultArray[i - 1]) + Number(calculationResultArray[i + 1]);
                calculationResultArray.splice(i - 1, 2);
                // console.log(calculationResultArray);
                calculationResultArray.splice(i - 1, 1, accumulator);
                processResultArray(calculationResultArray);
            }
            if (calculationResultArray[i] == "-") {
                accumulator = Number(calculationResultArray[i - 1]) - Number(calculationResultArray[i + 1]);
                calculationResultArray.splice(i - 1, 2);
                // console.log(calculationResultArray);
                calculationResultArray.splice(i - 1, 1, accumulator);
                processResultArray(calculationResultArray);
            }
        }

        return accumulator;
    }
}

// Some hints:
// You will only want to be able to add a "." ie a point once to a current number.
// Remember a number cannot divide by zero. You may want to deal with NaN.
// ***********************end of Calculator functionalities******************************

function pemdasCheck(array) {
    // array <- do all tests
}